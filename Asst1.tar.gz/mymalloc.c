#include "mymalloc.h"
#include <stdio.h>
#include <stddef.h>

int findFreeSpace(size_t size, char** file, int line)
{
	// This function loops through myblock to find an appropriate amount of memory for each call to malloc.
	// we use integers 'freed' and 'notFree' to denote if a position in malloc is being used or not
	// the short ints byte1 and byte2 are used to insert the size of the block as metadata.
	// PreviousFree is used to keep track if the last block iterated through myblock was freed or not.
	int i = 0;
	short int byte1;
	short int byte2;
	short int begin;
	int previousFree = -1;
	while(i <= 4096)
	{
		if((myblock[0] != freed) && (myblock[0] != notFree))
		{
			// myblock is empty, insert metadata and return position of myblock.
			previousFree = -1;
			myblock[0] = notFree;
			if((size / 100) < 1)
			{
				byte1 = 0;
			}
			else if((size / 100) >= 1)
			{
				byte1 = (size / 100);
			}
			byte2 = (size % 100);
			myblock[1] = byte1;
			myblock[2] = byte2;
			begin = 3;
			return begin;
		}
		else if((myblock[i] == notFree) || (myblock[i] == freed))
		{
			// variable sum is used to get the size of the current block being analyzed.
			short int sum;
			sum = (myblock[i + 1] * 100) + (myblock[i + 2] % 100);
			if(myblock[i] == freed)
			{
				// The position is freed. see if size retrieved at 'sum' is big enough for the request.
				previousFree = i;
				if(sum >= size)
				{
					if((sum - size) > 3)
					{
						// the block is big enough to hold two calls to malloc. Make the leftover memory free for use later on.
						size_t newSize;
						short int xbyte1;
						short int xbyte2;
						newSize = (sum - size) - 3;
						if((newSize / 100) < 1)
						{
							xbyte1 = 0;
						}
						else if((newSize / 100) >= 1)
						{
							xbyte1 = (newSize / 100);
						}
						xbyte2 = (newSize % 100);
						myblock[i + size + 3] = freed;
						myblock[i + size + 4] = xbyte1;
						myblock[i + size + 5] = xbyte2;
					}
					else
					{
						// The block is not big enough to hold two calls to malloc, allocate whatever is left along with the
						// original call to malloc.
						size = sum;
					}
					// Insert required metadata and return begin.
					myblock[i] = notFree;
					
					if((size / 100) < 1)
					{
						byte1 = 0;
					}
					else if((size / 100) >= 1)
					{
						byte1 = (size / 100);
					}
					byte2 = (size % 100);
					myblock[i + 1] = byte1;
					myblock[i + 2] = byte2;
					begin = (i + 3);
					return begin;
				}
				else
				{
					// The block is not big enough for the requested size, go to next block, check for error.
					if((i + (sum + 3)) > 4093)
					{
						printf("Error! Not enough memory available to allocate. %s at line %d.\n", *file, line);
						return 0;
					}
					else
					{
						i = (sum + 3) + i;
					}
				}
			}
			else
			{
				// The position is notFree, go to the next block as long as there is no error.
				previousFree = -1;
				if((i + (sum + 3)) > 4093)
				{
					printf("Error! Not enough memory available to allocate. %s at line %d.\n", *file, line);
					return 0;
				}
				else
				{
					i = (sum + 3) + i;
				}
			}
		}
		else if((myblock[i] != freed) && (myblock[i] != notFree))
		{
			// The position is neither freed and notFree. This means the rest of myblock is untouched.
			if(previousFree == -1)
			{
				// If previousFree == -1 that means the last block encountered was notFree. Proceed as normal.
				if((size + (i + 2)) > 4096)
				{
					printf("Error! Not enough memory available to allocate. %s at line %d.\n", *file, line);
					return 0;
				}
				else
				{
					// Insert metadata and return begin.
					myblock[i] = notFree;
					if((size / 100) < 1)
					{
						byte1 = 0;
					}
					else if((size / 100) >= 1)
					{
						byte1 = (size / 100);
					}
					byte2 = (size % 100);
					myblock[i + 1] = byte1;
					myblock[i + 2] = byte2;
					begin = (i + 3);
					return begin;
				}
			}
			else
			{
				// The last block is free, so go back and complete the call to malloc at that free block since the rest of myblock is 
				// untouched.
				if((size + (previousFree + 2)) > 4096)
				{
					printf("Error! Not enough memory available to allocate. %s at line %d.\n", *file, line);
					return 0;
				}
				else
				{
					myblock[previousFree] = notFree;
					if((size / 100) < 1)
					{
						byte1 = 0;
					}
					else if((size / 100) >= 1)
					{
						byte1 = (size / 100);
					}
					byte2 = (size % 100);
					myblock[previousFree + 1] = byte1;
					myblock[previousFree + 2] = byte2;
					begin = (previousFree + 3);
					return begin;
				}
			}
		}
	}
}

void* mymalloc(size_t n, char* file, int line)
{
	void* ptr;
	int begin;
	if(n > 4093)
	{
		// This print statement checks if the requested size of the malloc is greater than allowed.
		printf("Error! Not enough memory available to allocate. %s at line %d.\n", file, line);
		return NULL;
	}
	else
	{
		// The function 'findFreeSpace' is called to find memory for the call to malloc. 
		begin = findFreeSpace(n, &file, line);
		if(begin == 0)
		{
			// The number 0 is returned if findFreeSpace throws an error. If that is the case, ptr is set to NULL
			//return NULL;
			ptr = NULL;
		}
		else
		{
			// Otherwise, mymalloc sets a pointer equal to an address in myblock.
			ptr = &myblock[begin];
		}
	}
	// return void pointer.
	return ptr;
}

void  myfree(void* data, char* file, int line){
  int inUse = notFree;
  int free = freed;
  int first = 0;
  int second = 0;
  char* data1 = data;
  char* beginning = &myblock[3];
  char* end = &myblock[4096];
  char* beginning1 = &myblock[0];
  char* end1 = &myblock[4093];
  int boolean = 0;
  int secondFree = 0;
  short int byte1;
  short int byte2;
  int third;
  if((data1 >= beginning) && (data1 <= end)){ // this tests to see if the pointer is in the "myblock" addresses, if it is not then it was not a pointer allocated by mymalloc
  data1 = (data1 - 3);

  if((*(char*)data1 == inUse)){ // here i test to make sure that the pointer that was given by the user is actually an in use block inside myblock. if it i set the block to the free flag.
  *(char*)data1 = free;
  char* originalFree = data1;
  char* finalFree = data1;
  char* originalFreeByte1 = originalFree + 1;
  char* originalFreeByte2 = originalFree + 2;
  char* dataTester;
  int boolean1 = 0;
  if(data1 == beginning1)
  	boolean1 = 1;
  else
  	data1 -= 1;
  	while((boolean == 0) && (data1 >= beginning1)){ // this while loop iterates back through myblock starting from the block that the user gave us. When it finds a "free" flag or an "in use" flag this stops.
  		
  		if(((*(char*)data1 == inUse) || (*(char*)data1 == free)) && (boolean1 == 0)){ // when the while loop finds a block next to the block the user pointed too, this examines if that block is free or not. if it, we comebine those two free blocks.
  			boolean = 1;
  			if(*(char*)data1 == free){
  				dataTester = data1;
  				char* dataTesterByte1 = dataTester + 1;
  				char* dataTesterByte2 = dataTester + 2;
  				
  				*(char*)originalFree = 0;// this block of code gets the size of the block that the user gave us. We have three bytes of metadata for every block. One byte to specify if the block is free or not, and two bytes to specify the size of the block.
  				originalFree++;
  				first = (*(char*)originalFree * 100);
  				*(char*)originalFree = 0;
    			originalFree++;
    			second = (first) + ((*(char*)originalFree) + 3);
    			int middleSize = second;
    			
    			
    			*(char*)originalFree = 0;
    			originalFree -= 2;
    			first = (*(char*)
    			dataTesterByte1 * 100);
    			second = (first) + ((*(char*)dataTesterByte2));// this gets the size of the free block next to the original one which we are trying to combine with the block that the user's pointer pointed too. 
    			
    			second = second + middleSize; // this adds there sizes together so we can connect them.
    			
    			
    			if((second / 100) < 1)// this chunk of code basically is used to store a short integer across two bytes in our myblock array.
                    {
                        byte1 = 0;
                    }
                    else if((second / 100) >= 1)
                    {
                        byte1 = (second / 100);
                    }
                    byte2 = (second % 100);
                    *(char*)dataTesterByte1 = byte1;
                    *(char*)dataTesterByte2 = byte2;
                secondFree = 1;
               	if((originalFree + middleSize) <= (end1)){
                	originalFree = originalFree + middleSize;
                	if((*(char*)originalFree == free)){
                		*(char*)originalFree = 0;
  						originalFree++;
  						first = (*(char*)originalFree * 100);
  						*(char*)originalFree = 0;
    					originalFree++;
    					second = (first) + ((*(char*)originalFree) + 3);
    					*(char*)originalFree = 0;
    					first = (*(char*)dataTesterByte1 * 100);
    					second = (second) + (first) + ((*(char*)dataTesterByte2));
    					
    					if((second / 100) < 1)
                    {
                        byte1 = 0;
                    }
                    else if((second / 100) >= 1)
                    {
                        byte1 = (second / 100);
                    }
                    byte2 = (second % 100);
                    *(char*)dataTesterByte1 = byte1;
                    *(char*)dataTesterByte2 = byte2;
                	
                	
                	}
                }
  			}
  		
  		}
  	
  	
  	data1 -= 1;
  	}
  	if((secondFree == 0)){// this code tests the block after the original block to see if that block is also free in which case it would need to be connected.
  				
  				originalFree++;
  				first = (*(char*)originalFree * 100);
    			originalFree++;
    			second = (first) + ((*(char*)originalFree) + 3);//gets the current size of the original block
    			originalFree -= 2;
    			
    			if((originalFree + second) <= (end1)){
                	originalFree = originalFree + second;
                	if((*(char*)originalFree == free)){ // this tests to see if the block next to the original one is free or not.
                		*(char*)originalFree = 0;
  						originalFree++;
  						first = (*(char*)originalFree * 100);
  						*(char*)originalFree = 0;
    					originalFree++;
    					second = (second) + (first) + ((*(char*)originalFree));// if it free, this grabs the size of the block and add its to the size of our original block from the user. 
    					*(char*)originalFree = 0;
    					
    					if((second / 100) < 1)// we use this store the size across two bytes in the metadata.
                    {
                        byte1 = 0;
                    }
                    else if((second / 100) >= 1)
                    {
                        byte1 = (second / 100);
                    }
                    byte2 = (second % 100);
                    *(char*)originalFreeByte1 = byte1;
                    *(char*)originalFreeByte2 = byte2;
                	
                	
                	}
                }
  	
  	
  	}
  	
  	
    
    data1 += 1;
    
    

  }//else if((*(char*)data1 == free)){
  else{// if the pointer the user gave us points to an already freed block we print this error.
    printf("Error in %s on line %d: ", file, line);
    printf("this allocation has already been freed\n");
  }
  }else{// if the pointer is not in bounds with myblock then we return this error.
    printf("Error in %s on line %d: ", file, line);
    printf("this pointer was not allocated by malloc\n");

  }


}

 
	







