#ifndef _MYMALLOC_H
#define _MYMALLOC_H
#define malloc(x) mymalloc(x, __FILE__, __LINE__)
#define free(x) myfree(x, __FILE__, __LINE__)
//#include <stdlib.h>
#include <stdio.h>
void* mymalloc (size_t n, char* file, int line);
void myfree(void* data, char* file, int line);
int findFreeSpace(size_t size, char** file, int line);
static int notFree = -125;
static int freed = -16;
static char myblock[4096];
#endif
