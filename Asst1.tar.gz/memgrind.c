
#include <stdio.h>
#include "mymalloc.h"
#include <sys/time.h>


long test_A()
{
	long timepassed;
	struct timeval time1;
	struct timeval time2;
	gettimeofday(&time1, 0);
	int loop;
	char* ptr;
	for(loop = 0; loop < 150; loop++)
	{
		ptr = (char*)malloc(1);
		free(ptr);
	}
	gettimeofday(&time2, 0);
	timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
	return timepassed;
	printf("Test A took %ld microseconds.\n", timepassed);
}

long test_B()
{
	long timepassed;
	struct timeval time1;
	struct timeval time2;
	gettimeofday(&time1, 0);
	int i;
	int y;
	char* arr0[50];
	for(y = 0; y < 150; y++)
	{
		for(i = 0; i < 50; i++)
		{
			arr0[i] = (char*)malloc(1);
		}
		for(i = 0; i < 50; i++)
		{
			free(arr0[i]);
			arr0[i] = NULL;
		}
	}
	gettimeofday(&time2, 0);
	timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
	return timepassed;
}

long test_C()
{
	long timepassed;
	struct timeval time1;
	struct timeval time2;
	gettimeofday(&time1, 0);
	int random = 0;
	int to_free = 0;
	char* arr1[50];
	int numMallocs = 0;
	srand(time(0));
	int numFrees = 0;
	int x = 1;
	while(numMallocs < 50)
	{
		random = (rand() % 2);
		if(rand() % 2 == 0)
		{
			arr1[numMallocs] = malloc(x);
			numMallocs++;
		}
		else
		{
			if(numMallocs > numFrees)
			{
				while(arr1[to_free] == NULL)
					to_free = rand() % numMallocs;
				free(arr1[to_free]);
				arr1[to_free] = NULL;
				numFrees++;
			}
		}
	}

	int j =0;
	for(j=0;j<50;j++)
	{
		if(arr1[j] != NULL)
		{
			free(arr1[j]);
			arr1[j]=NULL;
		}
	}
	gettimeofday(&time2, 0);
	timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
	return timepassed;
}

long test_D()
{
	long timepassed;
	struct timeval time1;
	struct timeval time2;
	gettimeofday(&time1, 0);
	int random = 0;
	int to_free = 0;
	char* arr1[50];
	int numMallocs = 0;
	srand(time(0));
	int numFrees = 0;
	while(numMallocs < 50)
	{
		random = (rand() % 64) + 1;
		if(rand() % 2 == 0)
		{
			arr1[numMallocs] = malloc(random);
			numMallocs++;
		}
		else
		{
			if(numMallocs > numFrees)
			{
				while(arr1[to_free] == NULL)
					to_free = rand() % numMallocs;
				free(arr1[to_free]);
				arr1[to_free] = NULL;
				numFrees++;
			}
		}
	}

	int j =0;
	for(j=0;j<50;j++)
	{
		if(arr1[j] != NULL)
		{
			free(arr1[j]);
			arr1[j]=NULL;
		}
	}
	gettimeofday(&time2, 0);
	timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
	return timepassed;
}

long test_E()
{	
	// This test case tests our program's ability to combine and make use of freed space.
	// If you print the contents of myblock after each loop through the various frees and mallocs you will see there will
	// only be one freed block and nothing else.
	long timepassed;
	struct timeval time1;
	struct timeval time2;
	gettimeofday(&time1, 0);
	int loop;
	for(loop = 0; loop < 50; loop++)
	{
		srand(time(0));
		int i;
		int rando[6];
		for(i = 0; i < 6; i++)
		{
			rando[i] = (rand() % 64) + 1;
		}
		char* ptr = malloc(rando[0]);
		char* ptr1 = malloc(rando[1]);
		free(ptr);
		char* ptr3 = malloc(rando[2]);
		char* ptr4 = malloc(rando[3]);
		free(ptr3);
		free(ptr4);
		char* ptr5 = malloc(rando[4]);
		free(ptr5);
		char* ptr6 = malloc(rando[5]);
		free(ptr6);
		free(ptr1);
	}
	gettimeofday(&time2, 0);
	timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
	return timepassed;
	
}

long test_F()
{
	long timepassed;
	struct timeval time1;
	struct timeval time2;
	gettimeofday(&time1, 0);
	char* ptr1 = malloc(10);
	free(ptr1);
	free(ptr1);// should produce an error saying this pointer was already freed.
	char *ptr2;
	free(ptr2);// should produce error saying this pointer was not allocated by mymalloc.
	char*ptr3 = malloc(5000);// should produce an overflow error for myblock.
	free(ptr3);
	char*ptr4 = malloc(1000);
	char*ptr5 = malloc(1000);
	char*ptr6 = malloc(1000);
	char*ptr7 = malloc(1000);
	char*ptr8 = malloc(1000);//should produce an overflow error. myblock should be full.
	free(ptr4);
	free(ptr5);
	free(ptr6);
	free(ptr7);
	free(ptr8); // should produce an error saying this pointer was not allocated by malloc.
	gettimeofday(&time2, 0);
	timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
	return timepassed;
}

int main(int argc, char** argv)
{
	//srand(time(0));
	long arrA[100];
	long arrB[100];
	long arrC[100];
	long arrD[100];
	long arrE[100];
	long arrF[100];
	
	int outerLoop;
	for(outerLoop = 0; outerLoop < 100; outerLoop++)
	{
		arrA[outerLoop] = test_A();
		arrB[outerLoop] = test_B();
		arrC[outerLoop] = test_C();
		arrD[outerLoop] = test_D();
		arrE[outerLoop] = test_E();
		arrF[outerLoop] = test_F();
	}
	int i;
	long meanA, meanB, meanC, meanD, meanE, meanF;
	meanA = 0;
	meanB = 0;
	meanC = 0;
	meanD = 0;
	meanE = 0;
	meanF = 0;
	for(i = 0; i < 100; i++)
	{
		meanA = meanA + arrA[i];
		meanB = meanB + arrB[i];
		meanC = meanC + arrC[i];
		meanD = meanD + arrD[i];
		meanE = meanE + arrE[i];
		meanF = meanF + arrF[i];
	}
	meanA = meanA / 100;
	meanB = meanB / 100;
	meanC = meanC / 100;
	meanD = meanD / 100;
	meanE = meanE / 100;
	meanF = meanF / 100;
	printf("Mean of test A was %ld microseconds.\n", meanA);
	printf("Mean of test B was %ld microseconds.\n", meanB);
	printf("Mean of test C was %ld microseconds.\n", meanC);
	printf("Mean of test D was %ld microseconds.\n", meanD);
	printf("Mean of test E was %ld microseconds.\n", meanE);
	printf("Mean of test F was %ld microseconds.\n", meanF);
	
	
	
	return 0;
}

